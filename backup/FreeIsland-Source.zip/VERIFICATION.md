# Verification · 2026-09-11

The update removes the floating menu disk, changes the collapsed island to a configurable black dot, adds expanded-island scaling, and corrects repeated native Win7 painting.

- Win7: 15 native core test groups passed, including sizing defaults, persistence, bounds and old settings migration. No CLR or external VC/UCRT runtime DLL is imported; x86 GUI subsystem remains 6.1.
- Both editions: the release EXE completed --smoke-test with exit 0. The real settings controls apply valid dimensions, reject invalid dimensions, and restore defaults. Stopwatch/countdown/reminder/safe shutdown, docking and ball edge tests also completed. No actual shutdown or startup changes were made.
- Win7: over a 2,200 ms idle interval, the real window received zero paints and native buttons received zero owner-draw events. Over a 2,200 ms running-countdown interval, the window painted three times and child buttons zero times. This checks continuous redraw regression, not all possible driver/compositor defects.
- Captures cover both desktop and classroom menus/settings/default dots and the maximum custom dot/island. Physical default dot diameter and upper-bound size were inspected from rendered pixels.
- Both installers passed embedded payload extraction and SHA-256 verification. Full install/uninstall was not exercised in this update.
- The additional standalone WPF core test executable could not be launched: Windows reported the generated artifacts/CoreBehaviorTests.exe missing. This also occurred after excluding the real shutdown adapter from that test build. No claim is made that the updated 16-group WPF core suite passed; production WPF UI checks passed separately. No security settings were changed.
- Windows 7 hardware, the reported teaching display and real touch drivers are unavailable here. Local verification cannot guarantee absence of flicker on those devices. No flashing demonstration was generated.

Native child clipping follows [Microsoft's child update-region documentation](https://learn.microsoft.com/en-us/windows/win32/gdi/child-window-update-region). The larger, nearly transparent input area follows [layered-window hit testing](https://learn.microsoft.com/en-us/windows/win32/winmsg/window-features).