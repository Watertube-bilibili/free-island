# 浮岛 Win7 专版

这是单独维护的原生 Windows 7 版本，面向 32 位和 64 位 Windows 7。应用和安装器均为 Win32 C++ 程序，不需要安装 .NET Framework、Visual C++ Redistributable、Node.js 或浏览器。运行时仅使用 Windows 系统 DLL；C++ 支持库静态链接。

运行 `dist/FreeIsland-Win7-Setup-1.0.0.exe`，选择开机静默启动、桌面快捷方式后点击「安装浮岛」。安装完成后点击「打开浮岛」，或从开始菜单打开「浮岛 Win7」。无需管理员权限。

默认使用课堂场景，并保留更紧凑的电脑场景。提供悬浮球、环形入口、可拖动和靠边收起的灵动岛、正计时、倒计时、全屏展示、日程提醒、可取消的预约关机、托盘及本地设置。Windows 7 版使用原生窗口与 GDI+ 重建界面，与原 WPF 版本分别构建。

安装目录：`%LOCALAPPDATA%\Programs\FreeIslandWin7`。设置与日程目录：`%APPDATA%\FreeIslandWin7`。两个版本的安装与数据目录相互独立。启动项位于当前用户的 `HKCU\Software\Microsoft\Windows\CurrentVersion\Run`，名称为 `FreeIslandWin7`，指向带引号的应用路径及 `--silent` 参数。

可从 Windows 7「控制面板 → 程序和功能」卸载，也可双击安装目录中的 `FreeIslandWin7.Uninstall.exe`。卸载器请求浮岛正常退出，不强制终止进程，只删除已知安装文件和属于该安装的快捷方式、注册表项；不递归删除目录。本地设置和日程默认保留。为删除正在运行的卸载器，它会复制到系统临时目录完成操作；该临时文件可通过 Windows 临时文件清理移除。

安装包内嵌应用及其 SHA-256 值，提取前使用 Windows CryptoAPI 验证。仅验证并提取、不安装的命令：

```powershell
.\dist\FreeIsland-Win7-Setup-1.0.0.exe --verify-payload "D:\free island\artifacts\win7-payload-check"
```

该命令只向指定目录提取应用与运行库许可文件，不会启动应用、创建快捷方式、写入启动项或修改正式数据。安装包的内嵌哈希用于发现损坏，不替代发布者数字签名。

从仓库根目录构建：

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\win7\build-native.ps1
```

构建使用 i686 MinGW-w64 / MSVCRT 工具链，生成 x86 PE，目标系统版本为 Windows 7。构建脚本和工具链仅供开发使用，最终用户只需运行安装包或便携应用。具体输出文件、导入 DLL 和校验值以构建结果为准。

当前尚未在实体 Windows 7 电脑或实体教学触摸大屏上完成验证。现代 Windows 上的构建、运行及安全模式检查，不能代替 Windows 7 真机、不同显卡或触摸驱动的兼容性测试。开发测试不会执行真实关机，也不会实际安装或更改操作系统启动设置。正式使用时，预约关机不会强制关闭其他应用。

## 2026-09-11 更新

菜单不再显示大圆底板。灵动岛收起为默认 4 像素的黑点，仍可点击和拖动；设置中可调整黑点为 3–20 像素、展开比例为 75%–150%，并应用或恢复默认。教室模式保留较大的透明点击区域。

修复了父窗口反复重绘覆盖原生按钮和输入框的闪烁原因。静止页面仅在内容变化时重绘，计时按可见秒数变化更新。本机检查通过，仍需在实际 Win7 显卡和教室大屏上确认效果。
