using System;
using System.Diagnostics;
using System.IO;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using Microsoft.Win32;

namespace FreeIsland.Installation
{
    internal static class Common
    {
        internal const string Product = "浮岛 · Free Island";
        internal const string UninstallKey = @"Software\Microsoft\Windows\CurrentVersion\Uninstall\FreeIsland";
        internal const string RunKey = @"Software\Microsoft\Windows\CurrentVersion\Run";
        internal const string MarkerContents = "FreeIsland per-user installation v1";
        internal static readonly string[] PayloadFiles = { "FreeIsland.exe", "FreeIsland.exe.config", "FreeIsland.ico", "FreeIsland.Uninstall.exe" };
        internal static string InstallPath { get { return Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Programs", "FreeIsland"); } }
        internal static string DataPath { get { return Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "FreeIsland"); } }
        internal static string ShortcutName { get { return "浮岛 Free Island.lnk"; } }

        internal static bool SamePath(string first, string second)
        {
            try { return String.Equals(Path.GetFullPath(first).TrimEnd(Path.DirectorySeparatorChar), Path.GetFullPath(second).TrimEnd(Path.DirectorySeparatorChar), StringComparison.OrdinalIgnoreCase); }
            catch { return false; }
        }

        internal static void ValidateInstallPath(string path)
        {
            if (!SamePath(path, InstallPath)) throw new InvalidOperationException("安装目录验证失败，未改动任何文件。");
            string current = Path.GetFullPath(path);
            while (!String.IsNullOrEmpty(current))
            {
                if (Directory.Exists(current) && (File.GetAttributes(current) & FileAttributes.ReparsePoint) != 0)
                    throw new InvalidOperationException("安装路径包含目录链接，无法安全地继续。");
                DirectoryInfo parent = Directory.GetParent(current);
                current = parent == null ? null : parent.FullName;
            }
        }

        internal static void StopInstalledApp()
        {
            try { using (EventWaitHandle signal = EventWaitHandle.OpenExisting(@"Local\FreeIsland.Exit")) signal.Set(); }
            catch (WaitHandleCannotBeOpenedException) { }
            DateTime deadline = DateTime.UtcNow.AddSeconds(8);
            while (DateTime.UtcNow < deadline)
            {
                bool found = false;
                foreach (Process process in Process.GetProcessesByName("FreeIsland"))
                {
                    using (process)
                    {
                        try { if (!process.HasExited && SamePath(process.MainModule.FileName, Path.Combine(InstallPath, "FreeIsland.exe"))) found = true; }
                        catch (System.ComponentModel.Win32Exception) { }
                        catch (InvalidOperationException) { }
                    }
                }
                if (!found) return;
                Thread.Sleep(150);
            }
            throw new IOException("浮岛仍在运行。请从系统托盘退出浮岛，再重新运行安装程序。");
        }

        internal static void SetStartup(bool enabled)
        {
            using (RegistryKey key = Registry.CurrentUser.CreateSubKey(RunKey))
            {
                if (enabled) key.SetValue("FreeIsland", "\"" + Path.Combine(InstallPath, "FreeIsland.exe") + "\" --silent");
                else if (StartupTargetsInstall(key.GetValue("FreeIsland") as string)) key.DeleteValue("FreeIsland", false);
            }
        }

        internal static bool StartupTargetsInstall(string value)
        {
            if (String.IsNullOrWhiteSpace(value)) return false;
            string executable;
            value = value.Trim();
            if (value.StartsWith("\""))
            {
                int end = value.IndexOf('"', 1);
                executable = end > 1 ? value.Substring(1, end - 1) : "";
            }
            else executable = value.Split(new[] { ' ' }, 2)[0];
            return SamePath(executable, Path.Combine(InstallPath, "FreeIsland.exe"));
        }

        internal static void CreateShortcut(string folder)
        {
            Directory.CreateDirectory(folder);
            object shell = null, shortcut = null;
            try
            {
                shell = Activator.CreateInstance(Type.GetTypeFromProgID("WScript.Shell", true));
                shortcut = shell.GetType().InvokeMember("CreateShortcut", BindingFlags.InvokeMethod, null, shell, new object[] { Path.Combine(folder, ShortcutName) });
                SetComProperty(shortcut, "TargetPath", Path.Combine(InstallPath, "FreeIsland.exe"));
                SetComProperty(shortcut, "WorkingDirectory", InstallPath);
                SetComProperty(shortcut, "Description", "浮岛 · 让时间与提醒，轻轻浮现");
                SetComProperty(shortcut, "IconLocation", Path.Combine(InstallPath, "FreeIsland.ico"));
                shortcut.GetType().InvokeMember("Save", BindingFlags.InvokeMethod, null, shortcut, null);
            }
            finally
            {
                if (shortcut != null && Marshal.IsComObject(shortcut)) Marshal.FinalReleaseComObject(shortcut);
                if (shell != null && Marshal.IsComObject(shell)) Marshal.FinalReleaseComObject(shell);
            }
        }

        private static void SetComProperty(object target, string property, object value)
        {
            target.GetType().InvokeMember(property, BindingFlags.SetProperty, null, target, new object[] { value });
        }

        internal static void RemoveOwnedShortcut(string folder)
        {
            string path = Path.Combine(folder, ShortcutName);
            if (!File.Exists(path)) return;
            object shell = null, shortcut = null;
            try
            {
                shell = Activator.CreateInstance(Type.GetTypeFromProgID("WScript.Shell", true));
                shortcut = shell.GetType().InvokeMember("CreateShortcut", BindingFlags.InvokeMethod, null, shell, new object[] { path });
                string target = Convert.ToString(shortcut.GetType().InvokeMember("TargetPath", BindingFlags.GetProperty, null, shortcut, null));
                if (SamePath(target, Path.Combine(InstallPath, "FreeIsland.exe"))) File.Delete(path);
            }
            finally
            {
                if (shortcut != null && Marshal.IsComObject(shortcut)) Marshal.FinalReleaseComObject(shortcut);
                if (shell != null && Marshal.IsComObject(shell)) Marshal.FinalReleaseComObject(shell);
            }
        }

        internal static void WriteLog(string message)
        {
            try
            {
                string directory = Path.Combine(Path.GetTempPath(), "FreeIsland-Logs");
                Directory.CreateDirectory(directory);
                File.AppendAllText(Path.Combine(directory, "installation.log"), DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + " " + message + Environment.NewLine, Encoding.UTF8);
            }
            catch { }
        }
    }
}
